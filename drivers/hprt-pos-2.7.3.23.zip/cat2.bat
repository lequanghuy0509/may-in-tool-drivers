D:\WinDDK\7600.16385.1\bin\selfsign\Inf2Cat /driver:. /os:7_X64,XP_X64,Vista_X64,Server2003_X64,7_X86,2000,XP_X86,Server2003_X86,Vista_X86

D:\WinDDK\7600.16385.1\bin\amd64\Signtool sign /v /n HPRT.com /t http://timestamp.digicert.com .\*.cat

pause
